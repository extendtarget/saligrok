<?php

return [
    'callAndOrderNavMenuLabel' => 'Take Orders',
];
