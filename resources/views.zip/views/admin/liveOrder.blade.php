@extends('admin.layouts.master')
@section("title")
Live Order - Dashboard
@endsection
@section('content')
<style>
    .order a {
        font-weight: bold;
    }
    .order a:hover {
        color: black !important;
        font-size: 16.5px;
        font-weight: bold;
    }
    .order-amount {
        color: #49b875;
        font-size: 1.0rem;
        font-weight: 700;
    }
    .block-bg-5 {
        background-color: rgb(251 156 42 / 21%);
    }
    .color-orange {
        color: #ff7200;
    }
    .no-data-text {
        font-weight: bold;
        font-size: 1.2rem;
        color: #dbdbdb;
    }
    .no-data-img {
        width: 20%;
        opacity: 12%;
    }
</style>

<div class="content mb-5" id="liveorders">
    
    <div class="d-flex justify-content-between mt-4 mb-0">
        <div>
            <h3><b>Live Orders</b></h3>
        </div>
        <div class="float-right">
            <span id="current-time-now" data-start="{{ time() }}" class="float-right color-green mx-2" style="font-size: 1.5rem; font-weight: 700;"></span>
        </div>
    </div>

    <div class="clearfix"></div>
    @role('Admin')
    <div class="row">
        <div class="col-6 col-xl-2 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default" href="javascript:void(0)">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">{{ $completedCount }}</div>
                            <div class="font-size-sm text-uppercase text-muted">Completed Orders</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-4">
                                <i class="dashboard-display-icon icon-checkmark color-green"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-6 col-xl-2 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default" href="javascript:void(0)">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">{{ $cancelledCount }}</div>
                            <div class="font-size-sm text-uppercase text-muted">Cancelled Orders</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-3">
                                <i class="dashboard-display-icon icon-cross color-red"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-6 col-xl-2 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default" href="javascript:void(0)">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">{{ $onGoingOrders }}</div>
                            <div class="font-size-sm text-uppercase text-muted">On Going Orders</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-1">
                                <i class="dashboard-display-icon icon-truck color-purple"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-6 col-xl-2 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default" href="javascript:void(0)">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">{{ $onlineDrivers }}</div>
                            <div class="font-size-sm text-uppercase text-muted">Online Drivers</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-1">
                                <i class="dashboard-display-icon icon-truck color-purple"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-6 col-xl-2 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default" href="javascript:void(0)">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">{{ number_format($driverOrderRate, 2) }}</div>
                            <div class="font-size-sm text-uppercase text-muted">Order Load Per Driver</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-1">
                                <i class="dashboard-display-icon icon-truck color-purple"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-6 col-xl-2 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default" href="javascript:void(0)">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">{{ config('setting.currencyFormat') }} {{ number_format($todayOrderRevenue, 2) }}</div>
                            <div class="font-size-sm text-uppercase text-muted">Total Sales Today</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-2">
                                <i class="dashboard-display-icon icon-coin-dollar color-cyan"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    @endrole
    <hr>
    <div class="row">
        <div class="col-12 col-xl-3 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">New</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-1">
                                <span class="dashboard-display-icon color-purple"><b>{{ count($newOrders) }}</b></span>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive" style="max-height: 400px;">
                        @if (count($newOrders) == 0)
                            <div class="align-items-center text-center">
                                <i class="icon-exclamation no-data-img"></i>
                                <span class="no-data-text"><br>No data to show</span>
                            </div>
                        @else
                            @foreach ($newOrders as $nO)
                                <div class="order row">
                                    <div class="col-8 col-xl-9">
                                        <a href="{{ route('admin.viewOrder', $nO->unique_order_id) }}" target="_blank">
                                        <span style="font-size: 15px;">#{{ substr($nO->unique_order_id, -7) }}</span>
                                        </a>
                                        <br>
                                        {{ $nO->user->name }} - {{ $nO->user->phone }}<br>
                                        <b>{{ $nO->restaurant->name }}</b><br>
                                        {{ $nO->updated_at->diffForHumans() }}
                                    </div>
                                    <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                        {{ config('setting.currencyFormat') }}{{ $nO->total }}<br>
                                        <span class="badge badge-color-5">{{ $nO->payment_mode }}</span><br><br>
                                        @if ($nO->delivery_type == 1)
                                        <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($nO->location)->lat }},{{ json_decode($nO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                        @endif
                                    </div>
                                </div>
                            <hr>
                            @endforeach
                        @endif
                    </div>
                </a>
            </div>
        </div>
        <div class="col-12 col-xl-3 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">Preparing</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-1">
                                <span class="dashboard-display-icon color-purple"><b>{{ count($preparingOrders) }}</b></span>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive" style="max-height: 400px;">
                        @if (count($preparingOrders) == 0)
                            <div class="align-items-center text-center">
                                <i class="icon-exclamation no-data-img"></i>
                                <span class="no-data-text"><br>No data to show</span>
                            </div>
                        @else
                        @foreach ($preparingOrders as $pO)
                            <div class="order row">
                                <div class="col-8 col-xl-9">
                                    <a href="{{ route('admin.viewOrder', $pO->unique_order_id) }}" target="_blank">
                                    <span style="font-size: 15px;">#{{ substr($pO->unique_order_id, -7) }}</span>
                                    </a>
                                    <br>
                                    {{ $pO->user->name }} - {{ $pO->user->phone }}<br>
                                    <b>{{ $pO->restaurant->name }}</b><br>
                                    {{ $pO->updated_at->diffForHumans() }}<br>
                                    Ready by: <b>{{ Carbon\Carbon::parse($pO->prep_time)->format('h:i A') }}</b>
                                </div>
                                <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                    {{ config('setting.currencyFormat') }}{{ $pO->total }}<br>
                                    <span class="badge badge-color-5">{{ $pO->payment_mode }}</span><br><br>
                                    @if ($pO->delivery_type == 1)
                                    <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($pO->location)->lat }},{{ json_decode($pO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                    @endif
                                </div>
                            </div>
                        <hr>
                        @endforeach
                        @endif
                    </div>
                </a>
            </div>
        </div>
        <div class="col-12 col-xl-3 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">Delivery Assigned</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-1">
                                <span class="dashboard-display-icon color-purple"><b>{{ count($deliveryAssignedOrders) }}</b></span>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive" style="max-height: 400px;">
                        @if (count($deliveryAssignedOrders) == 0)
                            <div class="align-items-center text-center">
                                <i class="icon-exclamation no-data-img"></i>
                                <span class="no-data-text"><br>No data to show</span>
                            </div>
                        @else
                        @foreach ($deliveryAssignedOrders as $dAO)
                            <div class="order row">
                                <div class="col-8 col-xl-9">
                                    <a href="{{ route('admin.viewOrder', $dAO->unique_order_id) }}" target="_blank">
                                    <span style="font-size: 15px;">#{{ substr($dAO->unique_order_id, -7) }}</span>
                                    </a>
                                    <br>
                                    {{ $dAO->user->name }} - {{ $dAO->user->phone }}<br>
                                    <b>{{ $dAO->restaurant->name }}</b><br>
                                    {{ $dAO->updated_at->diffForHumans() }}<br>
                                    @if ($dAO->delivery_type = '1' && $dAO->accept_delivery->user)
                                        Delivery Guy: <b>{{ $dAO->accept_delivery->user->name }}</b><br>
                                    @endif
                                    Ready by: <b>{{ Carbon\Carbon::parse($dAO->prep_time)->format('h:i A') }}</b>
                                </div>
                                <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                    {{ config('setting.currencyFormat') }}{{ $dAO->total }}<br>
                                    <span class="badge badge-color-5">{{ $dAO->payment_mode }}</span><br><br>
                                    @if ($dAO->delivery_type == 1)
                                    <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($dAO->location)->lat }},{{ json_decode($dAO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                    @endif
                                </div>
                            </div>
                        <hr>
                        @endforeach
                        @endif
                    </div>
                </a>
            </div>
        </div>
        <div class="col-12 col-xl-3 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">Picked Up</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-1">
                                <span class="dashboard-display-icon color-purple"><b>{{ count($pickedUpOrders) }}</b></span>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive" style="max-height: 400px;">
                        @if (count($pickedUpOrders) == 0)
                            <div class="align-items-center text-center">
                                <i class="icon-exclamation no-data-img"></i>
                                <span class="no-data-text"><br>No data to show</span>
                            </div>
                        @else
                        @foreach ($pickedUpOrders as $pUO)
                            <div class="order row">
                                <div class="col-8 col-xl-9">
                                    <a href="{{ route('admin.viewOrder', $pUO->unique_order_id) }}" target="_blank">
                                    <span style="font-size: 15px;">#{{ substr($pUO->unique_order_id, -7) }}</span>
                                    </a>
                                    <br>
                                    {{ $pUO->user->name }} - {{ $pUO->user->phone }}<br>
                                    <b>{{ $pUO->restaurant->name }}</b><br>
                                    {{ $pUO->updated_at->diffForHumans() }}<br>
                                    @if ($pUO->delivery_type == '1' && $pUO->accept_delivery->user)
                                        Delivery Guy: <b>{{ $pUO->accept_delivery->user->name }}</b>
                                    @endif
                                </div>
                                <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                    {{ config('setting.currencyFormat') }}{{ $pUO->total }}<br>
                                    <span class="badge badge-color-5">{{ $pUO->payment_mode }}</span><br><br>
                                    @if ($pUO->delivery_type == 1)
                                    <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($pUO->location)->lat }},{{ json_decode($pUO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                    @endif
                                </div>
                            </div>
                        <hr>
                        @endforeach
                        @endif
                    </div>
                </a>
            </div>
        </div>
        @if(config('setting.enSPU')=="true" )
            <div class="col-12 col-xl-3 mb-2 mt-2">
                <div class="col-xl-12 dashboard-display p-3">
                    <a class="block block-link-shadow text-left text-default">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="dashboard-display-number">Ready for Pickup</div>
                                <sub>(Self-Pickup Orders)</sub>
                            </div>
                            <div class="d-none d-sm-block">
                                <div class="dashboard-display-icon-block block-bg-1">
                                    <span class="dashboard-display-icon color-purple"><b>{{ count($pickupReadyOrders) }}</b></span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="table-responsive" style="max-height: 400px;">
                            @if (count($pickupReadyOrders) == 0)
                                <div class="align-items-center text-center">
                                    <i class="icon-exclamation no-data-img"></i>
                                    <span class="no-data-text"><br>No data to show</span>
                                </div>
                            @else
                            @foreach ($pickupReadyOrders as $pRO)
                                <div class="order row">
                                    <div class="col-8 col-xl-9">
                                        <a href="{{ route('admin.viewOrder', $pRO->unique_order_id) }}" target="_blank">
                                        <span style="font-size: 15px;">#{{ substr($pRO->unique_order_id, -7) }}</span>
                                        </a>
                                        <br>
                                        {{ $pRO->user->name }} - {{ $pRO->user->phone }}<br>
                                        <b>{{ $pRO->restaurant->name }}</b><br>
                                        {{ $pRO->updated_at->diffForHumans() }}<br>
                                    </div>
                                    <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                        {{ config('setting.currencyFormat') }}{{ $pRO->total }}<br>
                                        <span class="badge badge-color-5">{{ $pRO->payment_mode }}</span><br><br>
                                        @if ($pRO->delivery_type == 1)
                                        <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($pRO->location)->lat }},{{ json_decode($pRO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                        @endif
                                    </div>
                                </div>
                            <hr>
                            @endforeach
                            @endif
                        </div>
                    </a>
                </div>
            </div>
        @endif
        @if(\Nwidart\Modules\Facades\Module::find('OrderSchedule') &&
            \Nwidart\Modules\Facades\Module::find('OrderSchedule')->isEnabled())
            <div class="col-12 col-xl-3 mb-2 mt-2">
                <div class="col-xl-12 dashboard-display p-3">
                    <a class="block block-link-shadow text-left text-default">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="dashboard-display-number">Scheduled</div>
                            </div>
                            <div class="d-none d-sm-block">
                                <div class="dashboard-display-icon-block block-bg-1">
                                    <span class="dashboard-display-icon color-purple"><b>{{ count($scheduledOrders) }}</b></span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="table-responsive" style="max-height: 400px;">
                            @if (count($scheduledOrders) == 0)
                                <div class="align-items-center text-center">
                                    <i class="icon-exclamation no-data-img"></i>
                                    <span class="no-data-text"><br>No data to show</span>
                                </div>
                            @else
                            @foreach ($scheduledOrders as $sO)
                                <div class="order row">
                                    <div class="col-8 col-xl-9">
                                        <a href="{{ route('admin.viewOrder', $sO->unique_order_id) }}" target="_blank">
                                        <span style="font-size: 15px;">#{{ substr($sO->unique_order_id, -7) }}</span>
                                        </a>
                                        <br>
                                        {{ $sO->user->name }} - {{ $sO->user->phone }}<br>
                                        <b>{{ $sO->restaurant->name }}</b><br>
                                        {{ $sO->updated_at->diffForHumans() }}<br>
                                        <b>Date:</b> {{ json_decode($sO->schedule_date)->day }},
                                            {{ json_decode($sO->schedule_date)->date }}
                                        <br>
                                        <b>Slot:</b> {{ json_decode($sO->schedule_slot)->open }} -
                                            {{ json_decode($sO->schedule_slot)->close }}
                                    </div>
                                    <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                        {{ config('setting.currencyFormat') }}{{ $sO->total }}<br>
                                        <span class="badge badge-color-5">{{ $sO->payment_mode }}</span><br><br>
                                        @if ($sO->delivery_type == 1)
                                        <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($sO->location)->lat }},{{ json_decode($sO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                        @endif
                                    </div>
                                </div>
                            <hr>
                            @endforeach
                            @endif
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-12 col-xl-3 mb-2 mt-2">
                <div class="col-xl-12 dashboard-display p-3">
                    <a class="block block-link-shadow text-left text-default">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="dashboard-display-number">Confirmed</div>
                                <sub>by store for Scheduled Order</sub>
                            </div>
                            <div class="d-none d-sm-block">
                                <div class="dashboard-display-icon-block block-bg-1">
                                    <span class="dashboard-display-icon color-purple"><b>{{ count($scheduleConfirmedOrders) }}</b></span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="table-responsive" style="max-height: 400px;">
                            @if (count($scheduleConfirmedOrders) == 0)
                                <div class="align-items-center text-center">
                                    <i class="icon-exclamation no-data-img"></i>
                                    <span class="no-data-text"><br>No data to show</span>
                                </div>
                            @else
                            @foreach ($scheduleConfirmedOrders as $sCO)
                                <div class="order row">
                                    <div class="col-8 col-xl-9">
                                        <a href="{{ route('admin.viewOrder', $sCO->unique_order_id) }}" target="_blank">
                                        <span style="font-size: 15px;">#{{ substr($sCO->unique_order_id, -7) }}</span>
                                        </a>
                                        <br>
                                        {{ $sCO->user->name }} - {{ $sCO->user->phone }}<br>
                                        <b>{{ $sCO->restaurant->name }}</b><br>
                                        {{ $sCO->updated_at->diffForHumans() }}<br>
                                        <b>Date:</b> {{ json_decode($sCO->schedule_date)->day }},
                                            {{ json_decode($sCO->schedule_date)->date }}
                                        <br>
                                        <b>Slot:</b> {{ json_decode($sCO->schedule_slot)->open }} -
                                            {{ json_decode($sCO->schedule_slot)->close }}
                                    </div>
                                    <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                        {{ config('setting.currencyFormat') }}{{ $sCO->total }}<br>
                                        <span class="badge badge-color-5">{{ $sCO->payment_mode }}</span><br><br>
                                        @if ($sCO->delivery_type == 1)
                                        <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($sCO->location)->lat }},{{ json_decode($sCO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                        @endif
                                    </div>
                                </div>
                            <hr>
                            @endforeach
                            @endif
                        </div>
                    </a>
                </div>
            </div>
        @endif
       <div class="col-12 col-xl-3 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">Completed</div>
                            <sub>upto recent 25 orders only</sub>
                        </div>
                        @role('Admin') <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-4">
                                <span class="dashboard-display-icon color-green"><b>{{ count($completedOrders) }}</b></span>
                            </div>
                        </div> @endrole
                    </div>
                    <hr>
                    <div class="table-responsive" style="max-height: 400px;">
                        @if (count($completedOrders) == 0)
                            <div class="align-items-center text-center">
                                <i class="icon-exclamation no-data-img"></i>
                                <span class="no-data-text"><br>No data to show</span>
                            </div>
                        @else
                        @foreach ($completedOrders->reverse()->take(25) as $cO)
                            <div class="order row">
                                <div class="col-8 col-xl-9">
                                    <a href="{{ route('admin.viewOrder', $cO->unique_order_id) }}" target="_blank">
                                    <span style="font-size: 15px;">#{{ substr($cO->unique_order_id, -7) }}</span>
                                    </a>
                                    <br>
                                    {{ $cO->user->name }} - {{ $cO->user->phone }}<br>
                                    <b>{{ $cO->restaurant->name }}</b><br>
                                    {{ $cO->updated_at->diffForHumans() }}<br>
                                    @if ($cO->delivery_type == '1')
                                        Delivery Guy: <b>{{ $cO->accept_delivery->user->name }}</b>
                                    @endif
                                </div>
                                <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                    {{ config('setting.currencyFormat') }}{{ $cO->total }}<br>
                                    <span class="badge badge-color-5">{{ $cO->payment_mode }}</span><br><br>
                                    @if ($cO->delivery_type == 1)
                                    <a class="btn btn-sm btn-dark" href="http://maps.google.com/maps?q={{ json_decode($cO->location)->lat }},{{ json_decode($cO->location)->lng }}" target="_blank"><i class="icon-pin"></i></a>
                                    @endif
                                </div>
                            </div>
                        <hr>
                        @endforeach
                        @endif
                    </div>
                </a>
            </div>
        </div>
        @role('Admin') <div class="col-12 col-xl-3 mb-2 mt-2">
            <div class="col-xl-12 dashboard-display p-3">
                <a class="block block-link-shadow text-left text-default">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="dashboard-display-number">Awaiting Payment</div>
                        </div>
                        <div class="d-none d-sm-block">
                            <div class="dashboard-display-icon-block block-bg-5">
                                <span class="dashboard-display-icon color-orange"><b>{{ count($awaitingOrders) }}</b></span>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="table-responsive" style="max-height: 400px;">
                        @if (count($awaitingOrders) == 0)
                            <div class="align-items-center text-center">
                                <i class="icon-exclamation no-data-img"></i>
                                <span class="no-data-text"><br>No data to show</span>
                            </div>
                        @else
                        @foreach ($awaitingOrders as $aO)
                            <div class="order row">
                                <div class="col-8 col-xl-9">
                                    <a href="{{ route('admin.viewOrder', $aO->unique_order_id) }}" target="_blank">
                                    <span style="font-size: 15px;">#{{ substr($aO->unique_order_id, -7) }}</span>
                                    </a>
                                    <br>
                                    {{ $aO->user->name }} - {{ $aO->user->phone }}<br>
                                    <b>{{ $aO->restaurant->name }}</b><br>
                                    {{ $aO->updated_at->diffForHumans() }}
                                </div>
                                <div class="col-4 col-xl-3 text-right align-items-center order-amount">
                                    {{ config('setting.currencyFormat') }}{{ $aO->total }}<br>
                                    {{ $aO->payment_mode }}
                                </div>
                            </div>
                        <hr>
                        @endforeach
                        @endif
                    </div>
                </a>
            </div>
        </div>@endrole
    </div>
</div>
<input type="hidden" id="server-timestamp" value="{{ Carbon\Carbon::now()->timestamp }}">
<script> 
    $(document).ready(function(){
    setInterval(function(){
        console.log("page reloaded");
          $("#liveorders").load(window.location.href + " #liveorders" );
    }, 15 * 1000);
    });

    var serverTime = "{{ $serverTime }}";
    var serverTimezone = "{{ $serverTimezone }}";
    // Parse server time with Carbon
    var freshTime = new Date(serverTime);

    function updateServerTime() {

        // Convert to server timezone
        freshTime.toLocaleString("en-US", { timeZone: serverTimezone });

        // Set text of the clock to show current time in "hh:mm:ss A" format
        $("#current-time-now").text(formatTime(freshTime));

        // Add a second to freshTime variable
        freshTime.setSeconds(freshTime.getSeconds() + 1);

    }

    function formatTime(date) {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        var ampm = hours >= 12 ? 'PM' : 'AM';

        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;

        return hours + ':' + minutes + ':' + seconds + ' ' + ampm;
    }

    // Update the server time every second
    setInterval(updateServerTime, 1000);

    // Initial update
    updateServerTime();
 
    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
    
@endsection