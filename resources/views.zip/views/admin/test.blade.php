Just for testing queries after passing data.
{{ $users }}