<style>
    {{ config('setting.adminCustomCss') }}
</style>