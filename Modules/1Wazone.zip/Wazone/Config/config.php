<?php

return [
    'name' => 'Wazone'
];
