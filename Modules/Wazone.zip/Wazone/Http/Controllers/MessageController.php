<?php

namespace Modules\Wazone\Http\Controllers;

use App\Order;
use Illuminate\Routing\Controller;
use Modules\Wazone\Http\Controllers\WazoneController;

class MessageController extends Controller {

    public function testMessage($phone) {
        $message = 'Test Message from Wazone Settings';
        $con = new WazoneController();
        $response = $con->wazone($phone, $message);
        if (empty($response['success'])) {
            return redirect()->back()->with(['message' => 'Send message failed!']);
        } else {
            return redirect()->back()->with(['success' => 'Message sent successfully!']);
        }
    }

    public function send($target, $phone, $param) {
        $con = new WazoneController();
        $message = $this->process($target, $param);
        $response = $con->wazone($phone, $message);
        return $response;
    }

    private function process($target, $param) {
        $filename = \Module::getModulePath('Wazone') . 'message_templates.json';
        if (file_exists($filename)) {
            $data = json_decode(file_get_contents($filename), true);
                switch ($target) {
                    case 'OTP':
                        $msg = $data['msg_otp'];
                        $message = str_replace('{otp}', $param['otp'], $msg);
                        return $message;
                    case 'STATUS2':
                        $msg = $data['msg_status2'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS3':
                        $msg = $data['msg_status3'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS4':
                        $msg = $data['msg_status4'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS5':
                        $msg = $data['msg_status5'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS6':
                        $msg = $data['msg_status6'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS7':
                        $msg = $data['msg_status7'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS8':
                        $msg = $data['msg_status8'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS9':
                        $msg = $data['msg_status9'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS10':
                        $msg = $data['msg_status10'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'STATUS11':
                        $msg = $data['msg_status11'];
                        $message = str_replace($this->find($param), array_values($param), $msg);
                        return $message;
                    case 'OWNER':
                        $msg = $data['msg_owner'];
                        $msg = str_replace($this->find($param), array_values($param), $msg);
                        break;
                    case 'DRIVER':
                        $msg = $data['msg_driver'];
                        $msg = str_replace($this->find($param), array_values($param), $msg);
                        break;
                    case 'STORE':
                        $msg = $data['msg_store'];
                        $msg = str_replace($this->find($param), array_values($param), $msg);
                        break;
                    case 'CUSTOMER':
                        $msg = $data['msg_customer'];
                        $msg = str_replace($this->find($param), array_values($param), $msg);
                        break;
                    case 'ADMIN':
                        $msg = $data['msg_admin'];
                        $msg = str_replace($this->find($param), array_values($param), $msg);
                        break;
                    case 'CANCEL':
                        $msg = $data['msg_cancel'];
                        $msg = str_replace($this->find($param), array_values($param), $msg);
                        break;
                }
                if (!empty(strpos($msg, '{items}'))) {
                    $items = $this->processItems($param['unique_order_id']);
                    $message = str_replace(['{target}', '{items}'], [$target, $items], $msg);
                } else {
                    $message = str_replace('{target}', $target, $msg);
                }
            return $message;
        } else { exit('file message_templates.json not found'); }
    }

    private function processItems($unique_order_id) {
        $msgItems = "";
        $order = Order::where('unique_order_id', $unique_order_id)->first();
        $pivotItems = $order->orderitems()->where('order_id', $order->id)->get();
        foreach ($pivotItems as $pI) {
            $msgItems = $msgItems . "(" . $pI->quantity . ") " . $pI->name . " @" . $pI->price . " = " . config('setting.currencyFormat') . $pI->quantity * $pI->price . "\r\n";
            $pivotAddons = $pI->order_item_addons()->where('orderitem_id', $pI->id)->get();
            foreach ($pivotAddons as $pA) {
                $msgItems = $msgItems . $pA->addon_category_name . "> " . $pA->addon_name . " @" . $pA->addon_price . " = " . config('setting.currencyFormat') . $pI->quantity * $pA->addon_price . "\r\n";
            }
        }
        return $msgItems;
    }

    private function find($param) {
        foreach ($param as $key => $val) {
            $param['{'.$key.'}'] = $val;
            unset($param[$key]);
        }
        return array_keys($param);
    }
}
?>