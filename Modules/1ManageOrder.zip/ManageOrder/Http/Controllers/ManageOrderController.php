<?php

namespace Modules\ManageOrder\Http\Controllers;

use Auth;
use App\User;
use App\Order;
use Exception;
use App\EagleView;
use App\Orderitem;
use App\Restaurant;
use App\CancelReason;
use App\OrderItemAddon;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Models\Activity;

class ManageOrderController extends Controller
{
        /** * Display a listing of the resource. 
         * * @return Response */
        public function index()
        {
                return view('manageorder::index');
        }
        /** * 
         * @param $order_id 
         * */
        public function viewOrder($order_id)
        {
                $user = auth()->user();
                if (config('setting.iHaveFoodomaaDeliveryApp') == "true") {
                        $eagleView = new EagleView();
                        $eagleViewData = $eagleView->getViewOrderSemiEagleViewData();
                        if ($eagleViewData == null) {
                                print_r("You have enabled I Have Delivery App in Admin Settings that requires delivery google services file to be correctly set on your server. delivery-google-services.json file is either missing or incorrect.Possible Solutions:Make sure the delivery-google-services.json is present on your server Or disable I have Delivery App from Admin Settings");
                                die();
                        }
                } else {
                        $eagleViewData = null;
                }
                $order = Order::where('unique_order_id', $order_id)->with('orderitems.order_item_addons', 'rating', 'razorpay_data')->first();
                $zone_id = session('selectedZone');
                if ($zone_id) {
                        $users = User::role('Delivery Guy')->with('delivery_guy_detail')->where('zone_id', $zone_id)->get();
                } else {
                        $users = User::role('Delivery Guy')->with('delivery_guy_detail')->get();
                }
                if ($order) {
                        $cancelReasons = [];

                        if ($order->orderstatus_id != 5 || $order->orderstatus_id != 6) {
                                $cancelReasons = CancelReason::whereHas('role', function ($q) use ($user) {
                                        $q->where('name', $user->roles[0]->name);
                                })->get();
                        }
                        $activities = Activity::where('subject_id', $order->id)->with('causer', 'causer.roles')->orderBy('id', 'DESC')->get();
                        return view('manageorder::admin.viewOrder', array('order' => $order, 'users' => $users, 'activities' => $activities, 'eagleViewData' => $eagleViewData, 'cancelReasons' => $cancelReasons));
                } else {
                        return redirect()->route('admin.orders');
                }
        }
        /**
         * * @param $order_id 
         */
        public function updateOrder(Request $request, $id)
        {
                $author = Auth::user();
                $orderTotal = 0;
                $order = Order::where('id', $id)->with('orderitems.order_item_addons')->lockForUpdate()->first();
                DB::beginTransaction();
                if ($request->delivery_type) {
                        if ($order->delivery_type != $request->delivery_type) {
                                $order->delivery_type = $request->delivery_type;
                        }
                }
                if ($request->has('free_delivery') && $request->free_delivery == true) {
                        $distance = $order->distance;
                        if ($order->restaurant->delivery_charge_type == 'DYNAMIC') {
                                //get distance between user and restaurant,

                                if ($distance > $order->restaurant->base_delivery_distance) {
                                        $extraDistance = $distance - $order->restaurant->base_delivery_distance;
                                        $extraCharge = ($extraDistance / $order->restaurant->extra_delivery_distance) * $order->restaurant->extra_delivery_charge;
                                        $dynamicDeliveryCharge = $order->restaurant->base_delivery_charge + $extraCharge;

                                        if (config('setting.enDelChrRnd') == 'true') {
                                                $dynamicDeliveryCharge = ceil($dynamicDeliveryCharge);
                                        }

                                        $order->actual_delivery_charge = $dynamicDeliveryCharge;
                                } else {
                                        $order->actual_delivery_charge = $order->restaurant->base_delivery_charge;
                                }
                        } else {
                                $order->actual_delivery_charge = $order->restaurant->delivery_charges;
                        }
                } elseif ($request->has('delivery_charge')) {
                        $order->delivery_charge = $request->delivery_charge;
                        $order->actual_delivery_charge = $request->actual_delivery_charge;
                }
                if ($request->has('restaurant_charge')) {
                        $order->restaurant_charge = $request->restaurant_charge;
                }

                $order->save();
                try {
                        $item_ids = $request->item_ids;
                        if (!is_null($item_ids)) {
                                $item_ids = explode(',', $item_ids);
                                if (count($item_ids) > 0) {
                                        foreach ($item_ids as $item_id) {
                                                $order_item = Orderitem::find($item_id)->delete();
                                                $order_item_addons = OrderItemAddon::where('orderitem_id', $item_id)->get();
                                                if ($order_item_addons) {
                                                        foreach ($order_item_addons as $order_item_addon) {
                                                                $order_item_addon->delete();
                                                        }
                                                }
                                        }
                                }
                        }
                        $name = $request->name;
                        $quantity = $request->quantity;
                        $price = $request->price;
                        if (count($name) > 0) {
                                foreach ($name as $key => $na_me) {
                                        if (!is_null($name[$key]) && !is_null($quantity[$key]) && !is_null($price[$key])) {
                                                $item = new Orderitem();
                                                $item->order_id = $id;
                                                $item->item_id = 0;
                                                $item->name = $name[$key];
                                                $item->quantity = $quantity[$key];
                                                $item->price = $price[$key];
                                                if ($order->orderstatus_id == 1 || $order->orderstatus_id == 2 || $order->orderstatus_id == 3 ||  $order->orderstatus_id == 4 || $order->orderstatus_id == 8 || $order->orderstatus_id == 10 || $order->orderstatus_id == 11) {
                                                        $item->save();
                                                }
                                        }
                                }
                        }
                        if ($order->orderstatus_id == 5) {
                                DB::rollBack();
                                return redirect()->back()->with(['message' => 'You can\'t manage this order as the order already completed!']);
                        } elseif ($order->orderstatus_id == 6) {
                                DB::rollBack();
                                return redirect()->back()->with(['message' => 'You can\'t manage this order as the order already cancelled!']);
                        }
                        $order = Order::with('orderitems.order_item_addons')->findOrFail($id);
                        foreach ($order->orderitems as $item) {
                                $itemTotal = ($item->price + $this->calculateAddonTotal($item->order_item_addons)) * $item->quantity;
                                $orderTotal = $orderTotal + $itemTotal;
                        }
                        $order->sub_total = $orderTotal;

                        //Commission Amounts Data saved here
                        $order->commission_rate = $order->restaurant->commission_rate;
                        $order->commission_amount = $order->commission_rate * $order->sub_total / 100;
                        $order->restaurant_net_amount = $order->sub_total + $order->restaurant_charge - $order->coupon_amount - $order->commission_amount;

                        if (config('setting.taxApplicable') == 'true') {
                                $order->tax = config('setting.taxPercentage');

                                $taxAmount = (float) (((float) config('setting.taxPercentage') / 100) * $orderTotal);
                        } else {
                                $taxAmount = 0;
                        }

                        $order->tax_amount = $taxAmount;

                        $order->restaurant_net_amount += $order->tax_amount;

                        $orderTotal = $orderTotal + $taxAmount;

                        $orderTotal -= $order->coupon_amount;

                        $orderTotal += $order->delivery_charge;
                        $orderTotal += $order->restaurant_charge;

                        $orderTotal = $orderTotal + $order->tip_amount;

                        //round off total if in decimal
                        $order->total = $orderTotal;

                        $order->final_profit = $order->commission_amount + $order->delivery_charge;

                        if ($order->delivery_charge == 0) {
                                $order->final_profit -= $order->actual_delivery_charge;
                        }

                        $user = User::where('id', $order->user_id)->first();
                        if ($order->orderstatus_id == 1 || $order->orderstatus_id == 2 || $order->orderstatus_id == 3 || $order->orderstatus_id == 4 || $order->orderstatus_id == 8 || $order->orderstatus_id == 10 || $order->orderstatus_id == 11) {
                                if ($order->payment_mode == "COD") {
                                        if ($order->wallet_amount != NULL) {
                                                if ($orderTotal > $order->wallet_amount) {
                                                        $balance_amount = $orderTotal - $order->wallet_amount;
                                                        $order->payable = $balance_amount;
                                                } else {
                                                        $balance_amount = $order->wallet_amount - $orderTotal;
                                                        if ($balance_amount > 0) {
                                                                $user->deposit($balance_amount * 100, ['description' => 'Added balance amount for manage order: ' . $order->unique_order_id]);
                                                        }
                                                        $order->wallet_amount = $orderTotal;
                                                        $order->payment_mode = "WALLET";
                                                        $order->payable = 0;
                                                }
                                        } else {
                                                $order->payable = $orderTotal;
                                        }
                                } elseif ($order->payment_mode == "WALLET") {
                                        if ($orderTotal > $order->wallet_amount) {
                                                if ($user->balanceFloat > 0) {
                                                        $balance_amount = $orderTotal - $order->wallet_amount;
                                                        if ($user->balanceFloat >= $balance_amount) {
                                                                $order->wallet_amount = $orderTotal;
                                                                $order->payable = 0;
                                                                $user->withdraw($balance_amount * 100, ['description' => 'Payment for manage order: ' . $order->unique_order_id]);
                                                        } else {
                                                                $payable_amount = $balance_amount - $user->balanceFloat;
                                                                $order->wallet_amount = $balance_amount + $user->balanceFloat;
                                                                $order->payable = $payable_amount;
                                                                $order->payment_mode = "COD";
                                                                //changed after omise integration ->
                                                                $order->restaurant_net_amount += $payable_amount;
                                                                // <- change end after omise integration
                                                                $user->withdraw($user->balanceFloat * 100, ['description' => 'Payment for manage order: ' . $order->unique_order_id]);
                                                        }
                                                } else {
                                                        $balance_amount = $orderTotal - $order->wallet_amount;
                                                        $order->payable = $balance_amount;
                                                        $order->payment_mode = "COD";
                                                        //changed after omise integration ->
                                                        $order->restaurant_net_amount += $balance_amount;
                                                        // <- change end after omise integration
                                                }
                                        } else {
                                                $balance_amount = $order->wallet_amount - $orderTotal;
                                                if ($balance_amount > 0) {
                                                        $user->deposit($balance_amount * 100, ['description' => 'Added balance amount for manage order: ' . $order->unique_order_id]);
                                                }
                                                $order->wallet_amount = $orderTotal;
                                                $order->payment_mode = "WALLET";
                                                $order->payable = 0;
                                        }
                                } else {
                                        if ($order->wallet_amount != NULL) {
                                                $paid_wallet = $order->wallet_amount;
                                                if ($order->actual_total > $paid_wallet) {
                                                        $paid_online = $order->actual_total - $paid_wallet;
                                                } else {
                                                        $paid_online = $paid_wallet - $order->actual_total;
                                                }
                                                $total_paid = $paid_wallet + $paid_online;
                                                if ($orderTotal > $total_paid) {
                                                        $balance_amount = $orderTotal - $total_paid;
                                                        $order->payable = $balance_amount;
                                                        $order->payment_mode = "COD";
                                                        //changed after omise integration ->
                                                        $order->restaurant_net_amount += $balance_amount;
                                                        // <- change end after omise integration
                                                } else {
                                                        if ($paid_online > $orderTotal) {
                                                                $balance_amount = $paid_online - $orderTotal;
                                                        } else {
                                                                $balance_amount = $orderTotal - $paid_online;
                                                        }
                                                        if ($balance_amount > 0) {
                                                                $user->deposit($balance_amount * 100, ['description' => 'Added balance amount for manage order: ' . $order->unique_order_id]);
                                                        }
                                                        $order->wallet_amount = NULL;
                                                }
                                        } else {
                                                if ($orderTotal > $order->actual_total) {
                                                        $user->deposit($order->actual_total * 100, ['description' => 'Convert ' . $order->payment_mode . ' amount as Wallet balance for manage order id ' . $order->unique_order_id]);
                                                        $user->withdraw($order->actual_total * 100, ['description' => 'Converted payment for order: ' . $order->unique_order_id . 'from ' . $order->payment_mode]);
                                                        $order->wallet_amount = $order->actual_total;
                                                        $balance_amount = $orderTotal - $order->actual_total;
                                                        $order->payable = $balance_amount;
                                                        $order->payment_mode = "COD";
                                                        //changed after omise integration ->
                                                        $order->restaurant_net_amount += $balance_amount;
                                                        // <- change end after omise integration
                                                } else {
                                                        $balance_amount = $order->actual_total - $orderTotal;
                                                        if ($balance_amount > 0) {
                                                                $user->deposit($balance_amount * 100, ['description' => 'Added balance amount for manage order ' . $order->unique_order_id]);
                                                        }
                                                }
                                        }
                                }
                                $order->save();
                        }
                        DB::commit();
                        activity()->performedOn($order)->causedBy($author)->withProperties(['type' => 'Order_Modified'])->log('Order modified');
                        return redirect()->back()->with(['success' => 'Order updated!']);
                } catch (\Illuminate\Database\QueryException $qe) {
                        return redirect()->back()->with(['message' => $qe->getMessage()]);
                } catch (Exception $e) {
                        return redirect()->back()->with(['message' => $e->getMessage()]);
                } catch (\Throwable $th) {
                        return redirect()->back()->with(['message' => $th]);
                }
        }
        /** * @param $order_id * @param $addons */ public function calculateAddonTotal($addons)
        {
                $total = 0;
                foreach ($addons as $addon) {
                        $total += $addon->addon_price;
                }
                return $total;
        }
}
