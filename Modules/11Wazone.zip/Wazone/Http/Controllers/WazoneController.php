<?php

namespace Modules\Wazone\Http\Controllers;

use Cache;
use App\User;
use App\Setting;
use App\Restaurant;
use Illuminate\Http\Request;
use Ixudra\Curl\Facades\Curl;
use Illuminate\Routing\Controller;
use Nwidart\Modules\Facades\Module;
use Modules\Wazone\Helper\JsonIndent;

class WazoneController extends Controller
{
        public function saveRestaurantNotifiable($id)
        {
                $restaurant = Restaurant::where('id', $id)->first();
                if ($restaurant->is_notifiable) {
                        $restaurant->is_notifiable = false;
                } else {
                        $restaurant->is_notifiable = true;
                }
                $restaurant->save();
                return redirect()->back()->with(['success' => 'Store Notifiable Saved!']);
        }
        public function saveUserNotifiable($id)
        {
                $user = User::where('id', $id)->first();
                if ($user->is_notifiable) {
                        $user->is_notifiable = false;
                } else {
                        $user->is_notifiable = true;
                }
                $user->save();
                return redirect()->back()->with(['success' => 'User Notifiable Saved!']);
        }
        public function saveWazoneSettings(Request $request)
        {
                $setting = Setting::where('key', 'enOLnR')->first();
                $setting->value = $request->enOLnR;
                $setting->save();
                $settings = Cache::forget('settings');
                $filename = Module::getModulePath('Wazone') . 'wazone_settings.json';
                if (file_exists($filename)) {
                        $data = json_decode(file_get_contents($filename), true);
                        $data['wazone_panel'] = rtrim($request->wazone_panel, "/");
                        $data['wazone_server'] = rtrim($request->wazone_server, "/");
                        $data['wazone_sender'] = $request->wazone_sender;
                        $data['wazone_token'] = $request->wazone_token;
                        $data['wazone_fallback'] = $request->wazone_fallback;
                        $data['wazone_timeout'] = $request->wazone_timeout;
                        //$json = str_replace('\\','',json_encode($data)); 
                        $json = json_encode($data);
                        $json = JsonIndent::beautify($json);
                        file_put_contents($filename, $json);
                        // return redirect()->back()->with(['success' => 'Wazone Settings Saved!']);
                } else {
                        return redirect()->back()->with(['message' => 'Please copy /Helper/wazone_settings.json and put it on root of wazone module!']);
                }
                $filename = Module::getModulePath('Wazone') . 'message_templates.json';
                if (file_exists($filename)) {
                        $data = json_decode(file_get_contents($filename), true);
                        $data['msg_owner'] = $request->msg_owner;
                        $data['msg_store'] = $request->msg_store;
                        $data['msg_driver'] = $request->msg_driver;
                        $data['msg_customer'] = $request->msg_customer;
                        $data['msg_admin'] = $request->msg_admin;
                        $data['msg_otp'] = $request->msg_otp;
                        $data['msg_status2'] = $request->msg_status2;
                        $data['msg_status3'] = $request->msg_status3;
                        $data['msg_status4'] = $request->msg_status4;
                        $data['msg_status5'] = $request->msg_status5;
                        $data['msg_status6'] = $request->msg_status6;
                        $data['msg_status7'] = $request->msg_status7;
                        $data['msg_status8'] = $request->msg_status8;
                        $data['msg_status9'] = $request->msg_status9;
                        $data['msg_status10'] = $request->msg_status10;
                        $data['msg_status11'] = $request->msg_status11;
                        $data['msg_cancel'] = $request->msg_cancel;
                        //$json = str_replace("\\","",json_encode($data)); 
                        $json = json_encode($data);
                        $json = JsonIndent::beautify($json);
                        file_put_contents($filename, $json);
                        return redirect()->back()->with(['success' => 'Server Settings & Message Templates Saved!']);
                } else {
                        return redirect()->back()->with(['message' => 'Please copy /Helper/message_templates.json and put it on root of wazone module!']);
                }
        }
        public function wazone($phone, $message)
        {
                if (is_null($phone)) {
                        return;
                }
                $filename = Module::getModulePath('Wazone') . 'wazone_settings.json';
                if (file_exists($filename)) {
                        $data = json_decode(file_get_contents($filename), true);
                        $wazone_panel = $data['wazone_panel'];
                        $wazone_server = $data['wazone_server'];
                        $wazone_sender = $data['wazone_sender'];
                        $wazone_token = $data['wazone_token'];
                        $wazone_fallback = $data['wazone_fallback'];
                        if ($wazone_fallback == 'none') {
                                $wazone_timeout = 1;
                        } else {
                                $wazone_timeout = $data['wazone_timeout'];
                        }
                } else {
                        die('Unable to open file wazone_settings.json for read!');
                }
                // $phoneWa = preg_replace('/\D/', '', $phone);
                if (!str_starts_with($phone, '+')) {
                        $phone = "+" . $phone;
                }
                $url = $wazone_server . '/api/send/whatsapp';
                $data = ['recipient' => $phone, 'message' => $message, 'account' => $wazone_sender, 'secret' => $wazone_token, 'type' => "text", "priority" => 1];
                $resp = Curl::to($url)
                        ->withContentType('application/x-www-form-urlencoded')
                        ->withData($data)
                        ->post();
                $resp = json_decode($resp, true);
                $status = $resp['status'];
                if (empty($resp)) {
                        $resp['success'] == true;
                        return ($resp);
                }
                $status = $status ?? $resp;
                if (empty($status)) {
                        $response = ['success' => false, 'type' => 'WHATSAPP',];
                } elseif ($status == 200) {
                        $response = ['success' => true, 'type' => 'WHATSAPP'];
                } elseif ($status != 200) {
                        $response = ['success' => false, 'type' => 'WHATSAPP'];
                } else {
                        $response = ['success' => true, 'type' => 'WHATSAPP'];
                }
                return $response;
        }
        public function url_get_contents($url)
        {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                return curl_exec($ch);
        }
        public function validate()
        {
                //         $domains = array('localhost', 'bejjurbites.com');
                //         $serverName = $_SERVER['SERVER_NAME'];
                //         foreach ($domains as $domain) {
                //                 if (strpos($serverName, $domain) > -1) return true;
                //         }
                //         $arr = $this->read_file();
                //         if (!empty($arr)) {
                //                 $license_key = base64_decode($arr['order_id']);
                //                 $rest_api = base64_decode($arr['rest_api']);
                //         } else {
                //                 return false;
                //         }
                //         if ($rest_api == '') {
                //                 $rest_api = base64_decode('P2NvbnN1bWVyX2tleT1ja19kMGVhMDFiZDAzNmRjMzA0MWViMjlmNDEyYjNjOTZlNzY3ZGJiYzhhJmNvbnN1bWVyX3NlY3JldD1jc18yYjNiOTVkZWY0MWM5YTNlYmU2NmZhMDI0NmFlYjNmYjg3NGViYjdj');
                //         }
                //         $url = "https://visimisi.net/wp-json/vm/v2/licenses/validate/" . $license_key . $rest_api;
                //         $ch = curl_init($url);
                //         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                //         $res = json_decode(curl_exec($ch), true);
                //         $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                //         curl_close($ch);
                //         if (!empty($res['success'])) {
                //                 if (!empty($res['data']['ipAddress']) && $res['data']['ipAddress'] != $res['data']['remAddress']) {
                //                         if ($res['data']['remainingActivations'] > 0) {
                //                                 return false;
                //                         } else {
                //                                 die('Error code: ' . $code . 'a');
                //                         }
                //                 }
                //                 if ($res['data']['timesActivated'] == 0) {
                //                         return false;
                //                 } else {
                //                         return true;
                //                 }
                //         } else if ($code == 0 && strlen($license_key) == 19) {
                //                 return true;
                //         } else {
                //                 return false;
                //         }
                return true;
        }
        public function activate($license_key)
        {
                // if (substr($license_key, 0, 4) == 'WFDM') {
                //         $rest_api = base64_decode('P2NvbnN1bWVyX2tleT1ja19kMGVhMDFiZDAzNmRjMzA0MWViMjlmNDEyYjNjOTZlNzY3ZGJiYzhhJmNvbnN1bWVyX3NlY3JldD1jc18yYjNiOTVkZWY0MWM5YTNlYmU2NmZhMDI0NmFlYjNmYjg3NGViYjdj');
                //         $url = "https://visimisi.net/wp-json/vm/v2/licenses/activate/" . $license_key . $rest_api;
                //         $ch = curl_init($url);
                //         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                //         $res = json_decode(curl_exec($ch), true);
                //         $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                //         curl_close($ch);
                //         if (!empty($res['success']) || $code == 0) {
                //                 $this->write_file($license_key, $rest_api);
                //         }
                //         return $res;
                // }
                return ($res['success'] = 'true');
        }
        private function read_file()
        {
                $filename = Module::getModulePath('Wazone') . 'Helper/helper.json';
                if (file_exists($filename)) {
                        $data = json_decode(file_get_contents($filename), true);
                        return $data;
                } else {
                        return false;
                }
        }
        private function write_file($license_key, $rest_api)
        {
                $filename = Module::getModulePath('Wazone') . 'Helper/helper.json';
                $data = ['order_id' => base64_encode($license_key), 'rest_api' => base64_encode($rest_api)];
                file_put_contents($filename, json_encode($data));
        }
        public function settings()
        {
                // $res = $this->validate();
                // if (empty($res)) return view('wazone::activate', ['license' => '']);
                $users = User::orderBy('id', 'DESC')->with('roles')->take(9)->get();
                $userCount = User::count();
                $restaurants = Restaurant::where('is_accepted', '1')->with('users.roles')->ordered()->paginate(20);
                $restaurantCount = Restaurant::count();
                $file_templates = Module::getModulePath('Wazone') . 'message_templates.json';
                if (!file_exists($file_templates)) copy(Module::getModulePath('Wazone') . 'Helper/message_templates.json', Module::getModulePath('Wazone') . 'message_templates.json');
                $template = json_decode(file_get_contents(Module::getModulePath('Wazone') . 'message_templates.json'), true);
                $file_settings = Module::getModulePath('Wazone') . 'wazone_settings.json';
                if (!file_exists($file_settings)) copy(Module::getModulePath('Wazone') . 'Helper/wazone_settings.json', Module::getModulePath('Wazone') . 'wazone_settings.json');
                $setting = json_decode(file_get_contents(Module::getModulePath('Wazone') . 'wazone_settings.json'), true);
                return view('wazone::settings', compact('users', 'userCount', 'restaurants', 'restaurantCount', 'template', 'setting'));
        }
        public function enableAllUsers()
        {
                $users = User::all();
                foreach ($users as $user) {
                        $user->is_notifiable = 1;
                        $user->update();
                }
                return redirect()->back()->with(['success' => 'All users enabled successfully!']);
        }
        public function disableAllUsers()
        {
                $users = User::all();
                foreach ($users as $user) {
                        $user->is_notifiable = 0;
                        $user->update();
                }
                return redirect()->back()->with(['success' => 'All users disabled successfully!']);
        }
        public function enableAllStores()
        {
                $restaurants = Restaurant::all();
                foreach ($restaurants as $restaurant) {
                        $restaurant->is_notifiable = 1;
                        $restaurant->update();
                }
                return redirect()->back()->with(['success' => 'All stores enabled successfully!']);
        }
        public function disableAllStores()
        {
                $restaurants = Restaurant::all();
                foreach ($restaurants as $restaurant) {
                        $restaurant->is_notifiable = 0;
                        $restaurant->update();
                }
                return redirect()->back()->with(['success' => 'All stores disabled successfully!']);
        }
}
