<?php

return [
    'name' => 'ThermalPrinter'
];
