<?php

namespace Modules\ThermalPrinter\Entities;

use Illuminate\Database\Eloquent\Model;

class PrinterSetting extends Model
{
    protected $fillable = [];
}
